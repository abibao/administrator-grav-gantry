<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Antimatter extends Theme
{

}
